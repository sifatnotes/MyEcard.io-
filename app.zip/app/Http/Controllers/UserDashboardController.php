<?php

namespace App\Http\Controllers;

use Illuminate\Http\Response;

class UserDashboardController extends AppBaseController
{
    /**
     * Display a listing of the resource.
     */
    public function index(): Response
    {
        //
    }
}
