<?php

return [

    'add_new' => 'Neue hinzufügen',
    'cancel' => 'Abbrechen',
    'save' => 'Speichern',
    'edit' => 'Bearbeiten',
    'detail' => 'Detail',
    'back' => 'Zurück',
    'action' => 'Aktion',
    'id' => 'Ausweis',
    'created_at' => 'Hergestellt in',
    'updated_at' => 'Aktualisiert am',
    'deleted_at' => 'Gelöscht um',
    'are_you_sure' => 'Bist du sicher?',
];
