<?php

return [
    'add_new' => 'Aggiungi Nuovo',
    'cancel' => 'Annulla',
    'save' => 'Salva',
    'edit' => 'Modifica',
    'detail' => 'Dettaglio',
    'back' => 'Indietro',
    'action' => 'Azione',
    'id' => 'ID',
    'created_at' => 'Creato il',
    'updated_at' => 'Aggiornato il',
    'deleted_at' => 'Eliminato il',
    'are_you_sure' => 'Sei sicuro?',
];
