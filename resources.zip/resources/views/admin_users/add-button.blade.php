<div>
    <a type="button" class="btn btn-primary ms-auto"
        href="{{ route('admins.create') }}">{{ __('messages.user.add_admin') }}</a>
</div>
