<label class="form-check form-switch form-check-custom form-check-solid form-switch-sm d-flex justify-content-center cursor-pointer">
    <input type="checkbox" name="is_active" class="form-check-input user-active cursor-pointer"
           data-id="{{$row->id}}" checked disabled>
    <span class="custom-switch-indicator"></span>
</label>
