<div>
    <div class="justify-content-center d-flex">
        <a title = "{{ __('messages.common.delete') }}" data-id="{{$row->id}}"
           class="btn px-1 text-danger fs-3 appointment-delete-btn">
            <i class="fa-solid fa-trash"></i>
        </a>
        </div>
</div>
