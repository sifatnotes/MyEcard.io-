<div>
    @if ($row->phone)
        {{ $row->phone }}
    @else
        {{ 'N/A' }}
    @endif
</div>
