<div class="alert alert-danger fs-4 text-white d-flex align-items-center" role="alert">
    <i class="fa-solid fa-face-frown me-5"></i>
    {{$error}}
</div>
