<script id="appointmentTemplate" type="text/x-jsrender">
<tr>
    <td>
        <div class="symbol symbol-45px me-2">
            <span class="text-muted fw-bold d-block">{{:vcardname}}</span>
        </div>
    </td>
    <td>
        <span class="text-muted fw-bold d-block">{{:name}}</span>
    </td>
    <td class="text-muted">
        <span class="text-muted fw-bold d-block text-nowrap">{{:phone}}</span>
    </td>
    <td>
        <span class="text-muted fw-bold d-block">{{:email}}</span>
    </td>
</tr>





</script>
