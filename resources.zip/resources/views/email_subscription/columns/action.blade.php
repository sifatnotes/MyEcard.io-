<div>
    <div class="justify-content-center d-flex">
    <a href="javascript:void(0)" data-id="{{ $row->id }}" title="{{ __('messages.common.delete') }}"
       class="btn px-1 text-danger fs-3 email-subscribe-delete-btn d-flex justify-content-center">
        <i class="fa-solid fa-trash"></i>
    </a>
    </div>
</div>
