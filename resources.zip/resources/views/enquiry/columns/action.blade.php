<div class="justify-content-start d-flex">
    <a title = "{{ __('messages.common.view') }}" data-id="{{$row->id}}"
       class="btn px-1 text-info fs-3 enquiries-view-btn">
        <i class="fa-solid fa-eye"></i>
    </a>
        <a title = "{{ __('messages.common.delete') }}" data-id="{{$row->id}}"
           class="btn px-1 text-danger fs-3 enquiries-delete-btn">
            <i class="fa-solid fa-trash"></i>
        </a>
    </div>
