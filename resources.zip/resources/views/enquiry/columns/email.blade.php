<a href="mailto:{{$row->email}}"
    class="text-decoration-none event-name text-center pt-3 mb-0">{{$row->email}}</a>
