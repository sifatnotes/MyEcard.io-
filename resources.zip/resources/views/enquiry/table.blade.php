<table class="table table-responsive-sm align-middle table-row-dashed fs-6 gy-5 dataTable no-footer w-100"
       id="enquiryTable">
    <thead>
    <tr class="text-start text-muted fw-bolder fs-7 text-uppercase gs-0">
        <th scope="col">{{__('messages.common.name')}}</th>
        <th scope="col">{{__('messages.common.email')}}</th>
        <th scope="col">{{__('messages.common.phone')}}</th>
        <th scope="col">{{__('messages.vcard.created_on')}}</th>
        <th scope="col">{{__('messages.common.action')}}</th>
    </tr>
    </thead>
    <tbody class="text-gray-600 fw-bold">
    </tbody>
</table>
