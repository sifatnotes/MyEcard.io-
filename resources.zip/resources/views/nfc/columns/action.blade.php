<div class="d-flex justify-content-center">
    <a title="{{ __('messages.common.view') }}" class="btn px-1 text-info fs-3" href="{{ route('my-nfc-orders.show', $row->id) }}">
        <i class="fa-solid fa-eye"></i>
    </a>
</div>
