<div>


    <div class="card" style="width: 9rem;">
        <img src="{{ $row->nfcCard->nfc_image }}" class="card-img-top rounded rounded-3" alt="..." height="80">
    </div>

</div>
