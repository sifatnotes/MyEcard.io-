<div>
    <span>+{{ $row->region_code }} {{ $row->phone }}</span>
</div>
