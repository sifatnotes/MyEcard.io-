<div class="justify-content-center d-flex">
    <a title="{{ __('messages.common.view') }}" href="{{ route('product-orders.show', $row->id) }}" class="btn px-1 text-info fs-3">
        <i class="fa-solid fa-eye"></i>
    </a>
</div>
