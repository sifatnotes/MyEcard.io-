{{ $row->currency->currency_icon }}{{ number_format($row->amount, 2) }}
