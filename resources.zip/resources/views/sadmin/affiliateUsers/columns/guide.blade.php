
@role('super_admin')
<div>
    <a type="button" class="btn btn-warning mt-5 mt-md-0" data-bs-target="#superAdminGuideAffiliationModal" id="superAdminGuideAffiliation" >{{ __('messages.affiliation.how_it_works') }}</a>
</div>
@endrole
