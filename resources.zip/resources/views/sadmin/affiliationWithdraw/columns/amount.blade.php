<span class="badge bg-success me-2">
    {{ currencyFormat($row->amount,2) }}
 </span>
