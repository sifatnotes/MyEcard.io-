<span class="badge bg-secondary me-2">
    {{ getFormattedDateTime($row->created_at)}}
 </span>
