<div>
    <a class="btn btn-primary ms-auto" id="newCityBtn">{{__('messages.city.new_city')}}</a>
</div>
