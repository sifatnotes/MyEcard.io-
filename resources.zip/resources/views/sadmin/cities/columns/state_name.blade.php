<div>
    {{ $row->state->name }}
</div>
