<div>
    <a class="btn btn-primary ms-auto" data-bs-toggle="modal" data-bs-target="#addCountryModal"
        id="newCountryBtn">{{ __('messages.country.new_country') }}</a>
</div>
