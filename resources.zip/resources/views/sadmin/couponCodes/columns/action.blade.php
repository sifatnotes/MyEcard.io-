<div>
    <div class="justify-content-center d-flex">
        <a title="{{ __('messages.common.edit') }}" data-id="{{ $row->id }}"
            class="btn px-1 text-info fs-3 edit-coupon-code">
            <i class="fa-solid fa-pen-to-square"></i>
        </a>
        <a title="{{ __('messages.common.delete') }}" data-id="{{ $row->id }}"
            class="btn px-1 text-danger fs-3 delete-coupon-code">
            <i class="fa-solid fa-trash"></i>
        </a>
    </div>
</div>
