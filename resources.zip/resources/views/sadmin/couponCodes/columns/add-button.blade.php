<div>
    <div class="card-toolbar custom-toolbar ms-auto">
        <div class="d-flex justify-content-end">
            <a type="button" class="btn btn-primary" data-bs-toggle="modal"
                data-bs-target="#couponCodeModal">{{ __('messages.coupon_code.add_coupon_code') }}</a>
        </div>
    </div>
</div>
