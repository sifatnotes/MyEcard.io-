<div>
    {{ $row->coupon_name }}
</div>
