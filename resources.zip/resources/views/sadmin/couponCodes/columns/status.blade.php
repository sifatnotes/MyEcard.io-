<div>
    <div class="form-check form-switch">
        <input class="form-check-input" type="checkbox" name="status" id="changeCouponStatus" data-id="{{ $row->id }}"
            {{ $row->status ? 'checked' : '' }}>
    </div>
</div>
