<div>
    <a type="button" class="btn btn-primary ms-auto" id="addFaqsBtn">{{ __('messages.faqs.addfaqs') }}</a>
</div>
