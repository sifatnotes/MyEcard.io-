<div class="d-flex align-items-center">
    <div class="d-flex flex-column">
        <span class="fs-6">{{ \Illuminate\Support\Str::limit($row->description, 30) }}</span>
    </div>
</div>
