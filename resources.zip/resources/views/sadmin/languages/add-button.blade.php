<div>
    <a href="javascript:void(0)" type="button" class="btn btn-primary ms-auto" id="addLanguage" data-target="#addLanguageModal">{{__('messages.languages.new_language')}}</a>
</div>
