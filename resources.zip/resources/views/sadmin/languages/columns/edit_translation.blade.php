<a class="text-decoration-none fs-6" href="{{ route('languages.translation',$row->id) }}">
    {{ __('messages.languages.edit_translation') }}
</a>
