<div>
    <a type="button" class="btn btn-warning mt-5 mt-md-0" data-bs-target="#superadminguideNfcModal" id="superadminguideNfc" >{{ __('messages.nfc.How_it_works') }}</a>
</div>

<div>
    <a type="button" class="btn btn-primary mt-5 mt-md-0 mx-2" data-bs-target="#addNfcModal" id="newNfc" >{{ __('messages.nfc.add_nfc_card') }}</a>
</div>
