<div>
<div class="card" style="width: 12rem;">
    <img src="{{ $row->nfc_image }}" class="card-img-top rounded rounded-3" alt="Vcard" height="120">
</div>
<p class="mt-3 ms-1">{{ $row->name }}</p>
</div>
