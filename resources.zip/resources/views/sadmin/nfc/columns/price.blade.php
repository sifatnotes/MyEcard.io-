<div>
    {{ currencyFormat($row->price,0,getSuperAdminSettingValue('default_currency')) }}
</div>
