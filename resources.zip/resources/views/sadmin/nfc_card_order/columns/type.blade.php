{{ App\Models\NfcOrders::PAYMENT_TYPE_ARR[$row->nfcTransaction->type] }}
