{{$row->notes ?? "N/A"}}
