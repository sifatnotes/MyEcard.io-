{!! ($row->plan->name) !!}
