{{ getFormattedDateTime($row->starts_at)}}
