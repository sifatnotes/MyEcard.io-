<div>
    <a type="button" class="btn btn-primary" href="{{ route('plans.create') }}">{{ __('messages.plan.new_plan') }}</a>
</div>
