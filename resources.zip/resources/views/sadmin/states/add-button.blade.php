<div>
    <a class="btn btn-primary ms-auto" id="newStateBtn">{{ __('messages.state.new_state') }}</a>
</div>
