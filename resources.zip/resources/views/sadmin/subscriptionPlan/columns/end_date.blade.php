{{ getFormattedDateTime($row->ends_at) }}
