{{ !empty($row->tenant->user) ? $row->tenant->user->full_name : '' }}
