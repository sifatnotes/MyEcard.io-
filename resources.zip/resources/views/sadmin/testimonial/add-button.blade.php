<div>
    <a type="button" class="btn btn-primary ms-auto" id="addTestimonialBtn">{{ __('messages.vcard.add_testimonial') }}</a>
</div>
