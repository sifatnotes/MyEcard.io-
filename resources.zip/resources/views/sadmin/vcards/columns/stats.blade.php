<a href="{{ route('sadmin.vcard.analytics', $row->id)}}">
    <i class="fa-solid fa-chart-line fs-2"></i>
</a>
