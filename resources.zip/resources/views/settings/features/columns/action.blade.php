<div>
    <div class="justify-content-center">
        <a href="{{ route('features.edit', $row->id) }}" title="{{ __('messages.common.edit') }}"
            class="btn px-1 text-primary fs-3">
            <i class="fa-solid fa-pen-to-square"></i>
        </a>
    </div>
</div>
