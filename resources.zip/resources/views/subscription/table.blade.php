<table class="table table-responsive-sm align-middle table-row-dashed fs-6 gy-5 dataTable no-footer w-100 text-nowrap"
       id="subscriptionTable">
    <thead>
    <tr class="text-start text-muted fw-bolder fs-7 text-uppercase gs-0">
        <th scope="col">{{__('messages.subscription.plan_name')}}</th>
        <th scope="col">{{__('messages.subscription.amount')}}</th>
        <th scope="col">{{__('messages.subscription.subscribed_date')}}</th>
        <th scope="col">{{__('messages.subscription.expired_date')}}</th>
        <th scope="col">{{__('messages.common.status')}}</th>
    </tr>
    </thead>
    <tbody class="text-gray-600 fw-bold text-nowrap">
    </tbody>
</table>
