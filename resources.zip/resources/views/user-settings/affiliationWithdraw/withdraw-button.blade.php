
@if (isAdmin())
    <div class="card-toolbar custom-toolbar ms-auto">
        <div class="d-flex justify-content-end"> <a type="button" class="btn btn-primary" data-bs-toggle="modal"
                data-bs-target="#withdrawAmountModal">{{ __('messages.affiliation.withdraw_amount') }}</a> </div>
    </div>

@endif
